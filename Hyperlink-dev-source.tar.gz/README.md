# Hyperlink

Hyperlink is a C++20 library skeleton for high-speed peer-to-peer data transfer between computers over a USB link, with automatic peer discovery and connection configuration.

## Development Setup

On macOS:

```sh
brew install cmake ninja pkg-config libusb
cmake --preset debug
cmake --build --preset debug
ctest --preset debug
```

On Linux:

```sh
# Debian/Ubuntu
sudo apt install build-essential cmake ninja-build pkg-config libusb-1.0-0-dev

# Fedora
sudo dnf install gcc-c++ cmake ninja-build pkgconf-pkg-config libusb1-devel

cmake --preset debug
cmake --build --preset debug
ctest --preset debug
```

On Windows, use one of these dependency paths:

```powershell
# vcpkg
vcpkg install libusb
cmake --preset debug -DCMAKE_TOOLCHAIN_FILE=C:\path\to\vcpkg\scripts\buildsystems\vcpkg.cmake
cmake --build --preset debug
ctest --preset debug
```

```sh
# MSYS2 MinGW shell
pacman -S mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja \
  mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-libusb
cmake --preset debug
cmake --build --preset debug
ctest --preset debug
```

If `libusb` is not installed, the project still builds and tests the portable library layer. The USB probing example will print that USB support is disabled.

## Project Layout

- `include/hyperlink/` public headers
- `src/` library implementation and transport backends
- `examples/` small programs for manual testing
- `tests/` assert-based smoke tests wired into CTest

## Performance Target

The long-term goal is to use the fastest transport exposed by the connected hardware, including USB4-class links when the OS and cable/device path make that available.

Important constraints:

- A USB4 port is not automatically a raw peer-to-peer data pipe between two computers.
- Generic `libusb` code can work well for USB devices with bulk endpoints, but it normally sees USB device speeds exposed by the operating system, not raw USB4 fabric bandwidth.
- Reaching USB4 20Gbps, 40Gbps, or 80Gbps class throughput may require a USB4/Thunderbolt networking interface, PCIe tunneling, a certified bridge device, or a custom device-mode/gadget endpoint depending on platform.
- Hyperlink should negotiate the best available link and report the detected/theoretical speed, then benchmark real application throughput separately.

## USB4/Thunderbolt Network Benchmark

When the OS exposes a USB4 or Thunderbolt connection as a network interface, use the TCP benchmark transport to measure the real application-level throughput.

On the receiving machine:

```sh
./build/debug/hyperlink_bench --server --host 0.0.0.0 --port 47777
```

On the sending machine, use the receiver's IP address on the USB4/Thunderbolt network interface:

```sh
./build/debug/hyperlink_bench --client --host <receiver-usb4-ip> --port 47777 --seconds 10
```

Helpful commands for finding the right interface:

```sh
# macOS
ifconfig
networksetup -listallhardwareports

# Linux
ip addr
ip route

# Windows PowerShell
Get-NetAdapter
Get-NetIPAddress
```

The benchmark uses TCP intentionally. That lets the operating system select the high-speed USB4/Thunderbolt network interface when the peer IP belongs to that link, while the same code remains portable across macOS, Linux, and Windows.

## Current Milestones

1. Define the public session, transport, and auto-configuration API.
2. Build a libusb discovery backend for compatible USB data-transfer devices.
3. Add the wire protocol handshake for role selection, packet sizing, encryption preference, and endpoint capabilities.
4. Add throughput and latency benchmarks using loopback/fake transport first, then real USB hardware.
5. Add OS-specific high-speed transports where useful, such as Thunderbolt/USB4 networking or PCIe-tunneled devices.

## Notes

Normal USB cables do not make two computers peers by themselves; one side normally acts as host and the other as device. For computer-to-computer transfer, plan around a USB bridge/data-transfer cable, a USB gadget/device-capable board, or another link that exposes bulk endpoints the library can claim.

The public API is intentionally platform-neutral. OS-specific work should stay behind `Transport` implementations so the session and auto-configuration layers remain portable.
